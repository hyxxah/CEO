/**
 * generate_full_report.js
 *
 * 부부 공동명의 1주택자 종합부동산세 검토 보고서(상세본, 7장 구성)를
 * .docx 파일로 생성한다. docs/review.md의 상세 버전에 해당.
 *
 * 사용법:
 *   npm install docx
 *   node generate_full_report.js
 *   -> 실행 디렉터리에 "종부세_검토보고서.docx" 생성
 */
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  WidthType, ShadingType, HeadingLevel, AlignmentType, BorderStyle, VerticalAlign
} = require("docx");

const PAGE_W = 12240, PAGE_H = 15840; // US Letter
const TABLE_W = 9360; // total usable width (DXA)

function cell(text, opts = {}) {
  const { width, bold = false, shade = null, align = AlignmentType.LEFT, size = 20 } = opts;
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    shading: shade ? { type: ShadingType.CLEAR, fill: shade } : undefined,
    verticalAlign: VerticalAlign.CENTER,
    margins: { top: 80, bottom: 80, left: 100, right: 100 },
    children: [
      new Paragraph({
        alignment: align,
        children: [new TextRun({ text, bold, size })],
      }),
    ],
  });
}

function headerRow(cells, widths) {
  return new TableRow({
    tableHeader: true,
    children: cells.map((t, i) => cell(t, { width: widths[i], bold: true, shade: "D9E2F3", align: AlignmentType.CENTER })),
  });
}

function dataRow(cells, widths, opts = []) {
  return new TableRow({
    children: cells.map((t, i) => cell(t, { width: widths[i], ...(opts[i] || {}) })),
  });
}

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 320, after: 160 },
    children: [new TextRun({ text, bold: true, size: 26 })],
  });
}

function p(text, opts = {}) {
  return new Paragraph({
    spacing: { after: 120 },
    children: [new TextRun({ text, size: 20, ...opts })],
  });
}

// ---------- Table 1: 대상자 현황 ----------
const w1 = [2400, 6960];
const table1 = new Table({
  width: { size: TABLE_W, type: WidthType.DXA },
  columnWidths: w1,
  rows: [
    headerRow(["구분", "내용"], w1),
    dataRow(["검토대상자", "본인 (1960년생, 2026년 기준 만 65~66세)"], w1),
    dataRow(["세대 구성", "본인 + 배우자 (동일세대)"], w1),
    dataRow(["보유주택 현황\n(2026.6.1 기준)",
      "① 공동명의: 서울 서초구 방배동 1018-1 (아크로 리츠카운티, 구 방배삼익아파트 재건축) — 관리처분인가 후 기존 건물 멸실, 현재 공사 중\n② 개인명의(본인): 주택 1채 — 2026년 9월 매도"], w1),
    dataRow(["재건축 준공 예정", "2027년 10월 (예정, 변동 가능)"], w1),
  ],
});

// ---------- Table 2: 연도별 종합부동산세 판정 요약 ----------
const w2 = [1400, 2600, 1900, 3460];
const table2 = new Table({
  width: { size: TABLE_W, type: WidthType.DXA },
  columnWidths: w2,
  rows: [
    headerRow(["과세연도\n(6/1 기준)", "세대 주택수 판정", "종부세\n해당 여부", "비고"], w2),
    dataRow(
      ["2026년",
       "개인명의 1채만 \"주택\"으로 인정 (공동명의 재건축분은 멸실 상태로 토지 분류, 종부세 비과세) → 1세대1주택자(개인명의)",
       "해당\n(1주택자 기준)",
       "9월 매도는 6/1 이후이므로 올해분 과세에 영향 없음. 국세청의 공동명의 특례 자동안내 대상 아님(공동명의 주택 자체가 없으므로)"],
      w2
    ),
    dataRow(
      ["2027년",
       "재건축 미준공 시 세대 내 종부세 과세대상 주택 없음 (개인명의 주택 매도완료, 공동명의분은 여전히 토지)",
       "해당 없음\n(주택분 없음)",
       "준공(2027.10 예정)이 6/1 이전으로 앞당겨질 경우 결과가 달라짐 — 조합·시공사 일정 확인 필요"],
      w2
    ),
    dataRow(
      ["2028년\n(예상)",
       "재건축 준공 후 공동명의 아파트 1채만 보유 → 1세대1주택자(공동명의)",
       "해당\n(1주택자 기준)",
       "개인별 과세 vs 공동명의 특례 중 유리한 쪽 선택 필요. 국세청 자동 유리세액 안내 대상 가능성"],
      w2
    ),
  ],
});

// ---------- Table 3: 공동명의 1주택자 특례 예상 혜택 (준공 이후 적용 가정) ----------
const w3 = [2600, 2900, 2900];
const table3 = new Table({
  width: { size: TABLE_W, type: WidthType.DXA },
  columnWidths: w3,
  rows: [
    headerRow(["항목", "개인별 과세\n(특례 미신청)", "공동명의 1주택자 특례\n(신청 시)"], w3),
    dataRow(["기본공제", "부부 각 9억원 (합계 최대 18억원)", "12억원(개편 후 실거주 14억원)"], w3),
    dataRow(["유리한 주택가액 구간", "세액공제 수준·공시가격에 따라 다름 → 5장 상세분석 참조", "세액공제 수준·공시가격에 따라 다름 → 5장 상세분석 참조"], w3),
    dataRow(["고령자 세액공제\n(만 65~70세 미만 → 30%)", "적용 불가", "30% 적용 가능"], w3),
    dataRow(["장기보유 세액공제\n(5~10년 20%, 10~15년 40%, 15년↑ 50%)",
      "적용 불가", "적용 가능 (재건축 전 취득일 통산 여부는 별도 확인 필요)"], w3),
    dataRow(["세액공제 합산한도", "-", "최대 80%"], w3),
    dataRow(["종부세 납부유예\n(60세 이상 또는 5년 이상 보유,\n총급여 8천만원 이하, 세액 100만원 초과)",
      "적용 불가", "요건 충족 시 상속·증여·양도 시점까지 유예 가능"], w3),
  ],
});

// ---------- Table 4-A: 세액공제 거의 없는 경우 ----------
const w4a = [2200, 2380, 2380, 2400];
const table4a = new Table({
  width: { size: TABLE_W, type: WidthType.DXA },
  columnWidths: w4a,
  rows: [
    headerRow(["가정", "시가", "개인별 과세", "공동명의 특례"], w4a),
    dataRow(["만 60대 초반\n· 보유 3년 (세액공제 미적용)", "30억원", "52.1만원", "190.1만원 → 개인별 과세 유리"], w4a),
  ],
});

// ---------- Table 4-B: 세액공제 최대(80%) 적용 시 ----------
const w4b = [2200, 2380, 2380, 2400];
const table4b = new Table({
  width: { size: TABLE_W, type: WidthType.DXA },
  columnWidths: w4b,
  rows: [
    headerRow(["가정", "시가", "개인별 과세", "공동명의 특례"], w4b),
    dataRow(["만 70세\n· 보유 15년 이상\n(세액공제 80%)", "30억원", "52.1만원", "38.0만원 → 특례 유리"], w4b),
    dataRow(["〃", "40억원", "326.4만원", "162.6만원 → 특례 유리"], w4b),
    dataRow(["〃", "50억원", "978.5만원", "783.1만원 → 특례 유리(격차 축소)"], w4b),
  ],
});

// ---------- Table 5: 신청방법 및 유의사항 ----------
const w4 = [2400, 6960];
const table4 = new Table({
  width: { size: TABLE_W, type: WidthType.DXA },
  columnWidths: w4,
  rows: [
    headerRow(["구분", "내용"], w4),
    dataRow(["신청기한", "매년 9월 16일 ~ 9월 30일, 관할세무서 또는 홈택스"], w4),
    dataRow(["국세청 자동안내", "2026년부터 국세청이 개인별 과세 vs 공동명의 특례 유불리를 직접 계산해 개별 안내 (별도 신청 없이도 유리한 세액으로 11월 정기고지 가능)"], w4),
    dataRow(["확인 필요① 멸실 반영", "국세청·구청 전산에 방배삼익 재건축분의 멸실(철거완료)이 정확히 반영되어 있는지 사전 확인 권장 — 미반영 시 2026년분이 2주택으로 오과세될 위험"], w4),
    dataRow(["확인 필요② 준공시기", "재건축 준공(사용승인)일이 2027년 6월 1일 이전/이후 어느 쪽인지에 따라 2027년분 과세 여부가 달라짐"], w4),
    dataRow(["확인 필요③ 보유기간 통산", "장기보유세액공제 산정 시 재건축 전 방배삼익아파트 취득일부터 통산되는지 여부는 세무사 확인 필요"], w4),
    dataRow(["확인 필요④ 2028년 제도개편", "2028년부터 세액공제 한도가 정률(최대80%)에서 최대 600만원 정액 한도로 변경 예정 — 고가주택일수록 특례의 절세효과가 줄어들 수 있음"], w4),
  ],
});

const doc = new Document({
  sections: [
    {
      properties: {
        page: { size: { width: PAGE_W, height: PAGE_H }, margin: { top: 1000, bottom: 1000, left: 1440, right: 1440 } },
      },
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 80 },
          children: [new TextRun({ text: "부부 공동명의 1주택자 종합부동산세 검토 보고서", bold: true, size: 32 })],
        }),
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 300 },
          children: [new TextRun({ text: "작성일: 2026-09-14", size: 18, color: "666666" })],
        }),

        h1("1. 검토 배경"),
        p("국세청은 2026년 9월, 부부 공동명의 1주택자에게 가장 유리한 종합부동산세(이하 '종부세') 계산방식을 직접 계산해 개별 안내하고, 과거 과다납부분도 발굴·환급하겠다고 발표하였음. 이에 따라 검토대상자의 주택 보유 현황을 기준으로 적용 가능 여부 및 예상 혜택을 검토함."),

        h1("2. 대상자 현황"),
        table1,

        h1("3. 연도별 종합부동산세 판정 요약"),
        p("* 종부세·재산세 과세기준일은 매년 6월 1일이며, 관리처분인가 후 건물이 멸실된 재건축 물건은 종부세법상 '주택'이 아닌 '토지'로 분류되어 종부세 과세대상에서 제외됨(종부세법 제11조).", { italics: true, color: "555555" }),
        table2,

        h1("4. 공동명의 1주택자 특례 예상 혜택 (준공 이후 적용 가정)"),
        table3,

        h1("5. 개인별 과세 vs 공동명의 특례 — 유불리 상세 분석 (실거주 기준)"),
        p("단순히 '공시가격 18억원 초과 시 특례가 유리하다'는 기준은 세액공제를 고려하지 않은 단순화된 기준임. 실제로는 연령·보유기간에 따른 세액공제 크기와 주택가액 수준이 함께 작용함."),
        p("[A] 세액공제가 거의 없는 경우 (예: 60대 초반, 단기보유)", { bold: true, size: 20 }),
        table4a,
        new Paragraph({ spacing: { before: 200, after: 120 }, children: [new TextRun({ text: "[B] 세액공제를 최대(80%)로 받는 경우 (예: 70세, 15년 이상 보유)", bold: true, size: 20 })] }),
        table4b,
        new Paragraph({ spacing: { before: 200, after: 80 }, children: [new TextRun({ text: "핵심 정리", bold: true, size: 20 })] }),
        p("· 실거주 + 세액공제 거의 없음 → 개인별 과세가 대체로 유리 (기본공제 18억 vs 14억 차이가 세액공제 효과보다 큼)"),
        p("· 실거주 + 세액공제 크고(고령·장기보유) 공시가격이 중고가(대략 25~50억원대) → 특례가 유리해지는 구간 발생"),
        p("· 공시가격이 극히 높아지는 초고가 구간 → 특례와 개인별 과세의 격차가 좁혀지며, 2028년 이후에는 다시 개인별 과세 쪽으로 유리함이 이동할 수 있음"),
        p("· 비거주(1세대1주택 거주요건 미충족) → 개인별 과세 시 공제가 각 4억(합 8억)으로 줄어 대체로 특례가 유리"),
        p("대상자(66세)는 고령자세액공제 30% 구간에 해당하나, 보유기간에 따른 장기보유세액공제분과 실제 준공 시점의 공시가격이 확정되어야 정확한 유불리 판단이 가능함. 최종적으로는 국세청 홈택스 자동계산 결과를 확인하는 것을 권장함.", { italics: true, color: "555555" }),

        h1("6. 신청방법 및 유의사항"),
        table4,

        h1("7. 결론"),
        p("① 2026년: 개인명의 주택 1채만 과세대상이며 9월 매도는 금년도 과세에 영향 없음. 공동명의 특례 관련 사안 없음."),
        p("② 2027년: 재건축이 예정대로 준공 전이면 세대 내 과세대상 주택이 없어 종부세 부담이 사실상 발생하지 않을 것으로 예상됨."),
        p("③ 2028년(준공 이후 예상): 공동명의 아파트 1채만 남아 1세대1주택자 지위를 갖추게 되며, 개인별 과세와 공동명의 특례 중 유리한 방식은 그 시점의 공시가격·보유기간에 따라 달라지므로 국세청 자동안내 결과를 확인하여 선택. 대상자는 1960년생으로 해당 시점 만 65~70세 구간에 속해 고령자세액공제(30%) 적용이 유력함."),
        p("본 보고서는 공개된 뉴스·국세청 자료를 바탕으로 한 참고용 검토 자료이며, 최종 신고·신청 전 관할 세무서 또는 세무사의 확인을 거치는 것을 권장함.", { italics: true, size: 18, color: "555555" }),

        h1("참고자료"),
        p("· 국세청, \"부부공동 1주택 유리한 세액 미리 안내\" 보도자료 (2026.9)", { size: 18 }),
        p("· \"26억 이하 1주택은 공동명의가 종부세 절감… 오래 거주한 고가주택은 1주택 특례 유리\" (2026.8)", { size: 18 }),
        p("· \"30억 아파트 공동명의 때… 개별과세 52만원 vs 특례 190만원\", 파이낸셜뉴스 (2026.8)", { size: 18 }),
        p("· \"재건축·재개발 사업 시행 단계에 따른 보유세\", 한국도시환경헤럴드", { size: 18 }),
      ],
    },
  ],
});

Packer.toBuffer(doc).then((buf) => {
  require("fs").writeFileSync("./종부세_검토보고서.docx", buf);
  console.log("done");
});
