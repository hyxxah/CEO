/**
 * generate_summary_report.js
 *
 * 부부 공동명의 1주택자 종합부동산세 검토 보고서(요약본, 최종 전달본)를
 * .docx 파일로 생성한다. 핵심 요약 박스 + 5개 섹션으로 구성.
 * docs/review.md 요약에 해당하는 최종 버전.
 *
 * 사용법:
 *   npm install docx
 *   node generate_summary_report.js
 *   -> 실행 디렉터리에 "종부세_검토보고서_요약.docx" 생성
 */
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  WidthType, ShadingType, HeadingLevel, AlignmentType, VerticalAlign
} = require("docx");

const PAGE_W = 12240, PAGE_H = 15840; // US Letter
const TABLE_W = 9360;

function cell(text, opts = {}) {
  const { width, bold = false, shade = null, align = AlignmentType.LEFT, size = 20 } = opts;
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    shading: shade ? { type: ShadingType.CLEAR, fill: shade } : undefined,
    verticalAlign: VerticalAlign.CENTER,
    margins: { top: 80, bottom: 80, left: 100, right: 100 },
    children: [new Paragraph({ alignment: align, children: [new TextRun({ text, bold, size })] })],
  });
}
function headerRow(cells, widths) {
  return new TableRow({ tableHeader: true, children: cells.map((t, i) => cell(t, { width: widths[i], bold: true, shade: "D9E2F3", align: AlignmentType.CENTER })) });
}
function dataRow(cells, widths) {
  return new TableRow({ children: cells.map((t, i) => cell(t, { width: widths[i] })) });
}
function h1(text) {
  return new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 280, after: 140 }, children: [new TextRun({ text, bold: true, size: 26 })] });
}
function p(text, opts = {}) {
  return new Paragraph({ spacing: { after: 100 }, children: [new TextRun({ text, size: 20, ...opts })] });
}

// 표1: 대상자 및 주택 현황
const w1 = [2400, 6960];
const table1 = new Table({
  width: { size: TABLE_W, type: WidthType.DXA }, columnWidths: w1,
  rows: [
    headerRow(["구분", "내용"], w1),
    dataRow(["대상자", "본인 (1960년생)"], w1),
    dataRow(["공동명의 주택", "서울 서초구 방배동 1018-1 (아크로 리츠카운티, 구 방배삼익아파트 재건축) — 현재 공사 중, 준공 예정 2027년 10월"], w1),
    dataRow(["개인명의 주택", "본인 소유 1채 — 2026년 9월 매도"], w1),
  ],
});

// 표2: 지금까지(2026~2027년) 해당 여부
const w2 = [1400, 1400, 6560];
const table2 = new Table({
  width: { size: TABLE_W, type: WidthType.DXA }, columnWidths: w2,
  rows: [
    headerRow(["연도", "해당 여부", "사유"], w2),
    dataRow(["2026년", "해당 없음",
      "6월 1일 기준 공동명의 재건축분은 멸실(철거) 상태로 '주택'이 아닌 '토지'로 분류되어 종부세 비과세 → 공동명의 주택 자체가 없어 특례 대상 아님. 개인명의 주택 1채만 과세대상(9월 매도는 6/1 이후라 올해분에 영향 없음)"], w2),
    dataRow(["2027년", "해당 없음",
      "재건축이 예정(2027.10)대로 준공 전이면 6월 1일 기준으로도 여전히 '토지' 상태 → 세대 내 종부세 과세대상 주택 자체가 없음"], w2),
  ],
});

// 표3: 개인별 과세 vs 공동명의 1주택자 특례 비교 (2028년 적용, 비거주·임대 가정)
const w3 = [2600, 3380, 3380];
const table3 = new Table({
  width: { size: TABLE_W, type: WidthType.DXA }, columnWidths: w3,
  rows: [
    headerRow(["항목", "개인별 과세", "공동명의 1주택자 특례"], w3),
    dataRow(["기본공제", "부부 각 9억원 (합 18억원)", "12억원 (비거주 기준)"], w3),
    dataRow(["고령자 세액공제\n(2028년 만 67~68세 → 30%)", "적용 불가", "적용 가능"], w3),
    dataRow(["장기보유(거주) 세액공제", "적용 불가", "비거주 시 거주요건 미충족으로 적용 어려움\n(2028년 개편안 기준)"], w3),
    dataRow(["세액공제 한도", "-", "최대 약 40%대\n(고령자공제 위주)"], w3),
    dataRow(["종부세 납부유예", "적용 불가", "요건(60세 이상 등) 충족 시 가능"], w3),
  ],
});

// 핵심 요약 박스 (상단 강조)
const wS = [9360];
const summaryBox = new Table({
  width: { size: TABLE_W, type: WidthType.DXA }, columnWidths: wS,
  rows: [
    headerRow(["핵심 요약"], wS),
    new TableRow({
      children: [
        new TableCell({
          width: { size: wS[0], type: WidthType.DXA },
          shading: { type: ShadingType.CLEAR, fill: "FFF7D6" },
          margins: { top: 140, bottom: 140, left: 160, right: 160 },
          children: [
            new Paragraph({ spacing: { after: 80 }, children: [new TextRun({ text: "① 공동명의 1주택(배우자) + 개인명의 1주택(본인) = 세대 합산 2주택 → 본인·배우자 모두 특례 해당 안 됨", bold: true, size: 20 })] }),
            new Paragraph({ spacing: { after: 80 }, children: [new TextRun({ text: "② 재건축 아파트는 사용승인(준공) 전까지는 '토지'로 분류되어 종부세상 주택이 아니며, 준공 후에야 '주택'으로 잡힘", bold: true, size: 20 })] }),
            new Paragraph({ children: [new TextRun({ text: "③ 특례 대상이 되면(2028년~) 해당 연도에 홈택스에서 유리한 쪽을 자동으로 계산해 안내 (2026년부터 시행)", bold: true, size: 20 })] }),
          ],
        }),
      ],
    }),
  ],
});

const doc = new Document({
  sections: [{
    properties: { page: { size: { width: PAGE_W, height: PAGE_H }, margin: { top: 1000, bottom: 1000, left: 1440, right: 1440 } } },
    children: [
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 }, children: [new TextRun({ text: "부부 공동명의 1주택자 종합부동산세 검토 (요약)", bold: true, size: 30 })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: "작성일: 2026-09-14", size: 18, color: "666666" })] }),

      summaryBox,
      new Paragraph({ spacing: { after: 160 }, children: [] }),

      h1("1. 대상자 및 주택 현황"),
      table1,

      h1("2. 지금까지(2026~2027년) — 해당 없음"),
      table2,

      h1("3. 2028년부터 — 공동명의 1주택자 해당"),
      p("· 재건축이 준공(2027.10 예정)되면 그 다음 과세기준일인 2028년 6월 1일부터, 개인명의 주택은 이미 매도된 상태이므로 세대 내 유일한 주택은 이 공동명의 아파트 1채가 됨 → 1세대1주택자(공동명의)에 해당하게 됨"),
      p("· 이때부터 '개인별 과세'와 '공동명의 1주택자 특례' 중 유리한 방식을 선택할 수 있으며, 어느 쪽이 유리한지는 국세청이 홈택스에서 자동으로 계산해 개별 안내함(2026년부터 시행된 서비스) — 별도로 유불리를 직접 계산하지 않아도, 신청 여부와 무관하게 유리한 세액으로 11월 정기고지를 받을 수 있음"),
      p("· 다만 매년 9월 16일~30일 신청기간에 공동명의 특례를 직접 신청·변경할 수도 있으며, 정확한 유불리는 준공 시점의 실제 공시가격이 확정된 후 홈택스 자동계산 결과로 최종 확인 필요"),

      h1("4. 개인별 과세 vs 공동명의 특례 비교 (참고용)"),
      table3,
      p("* 실거주하지 않고 임대하는 경우를 가정. 위 항목별 적용 여부는 2026년 세제개편안(국회 심사 중) 확정 내용에 따라 달라질 수 있으며, 최종 유불리는 3장에서 설명한 홈택스 자동계산으로 확인됨.", { italics: true, size: 18, color: "555555" }),

      h1("5. 유의사항"),
      p("· 재건축분의 멸실(철거완료)이 국세청·구청 전산에 정확히 반영되어 있는지 사전 확인 권장 (미반영 시 2026·2027년분이 2주택으로 오과세될 위험)"),
      p("· 준공(사용승인) 시기가 2027년 6월 1일 이전으로 앞당겨질 경우 2027년분부터 해당될 수 있음 — 조합·시공사 일정 확인 필요"),
      p("본 자료는 공개된 뉴스·국세청 자료를 바탕으로 한 참고용 검토 자료이며, 최종 신고·신청 전 관할 세무서 또는 세무사 확인을 권장함.", { italics: true, size: 18, color: "555555" }),
    ],
  }],
});

Packer.toBuffer(doc).then((buf) => {
  require("fs").writeFileSync("./종부세_검토보고서_요약.docx", buf);
  console.log("done");
});
